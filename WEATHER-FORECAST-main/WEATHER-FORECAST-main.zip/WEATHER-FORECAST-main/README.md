# WEATHER-FORECAST
WEATHER FORECAST [HTML/CSS/JS/API]


API (https://openweathermap.org/)
